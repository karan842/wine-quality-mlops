# MLOPS project end to end

Using DVC and MLoPS workflow
